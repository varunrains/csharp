# grpc-csharp-course

## Reminder

- In order to run SSL features, do not forget to run the shell script
- If you find any missing or uncorrect code, please report an issue.
- Feel free to make pull requests !
